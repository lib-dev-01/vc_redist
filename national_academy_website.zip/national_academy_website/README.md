# National Academy of Sciences Website

A comprehensive, modern website for a National Academy featuring 24 research institutes.

## 📁 Project Structure

```
national_academy_website/
├── index.html              # Homepage
├── css/
│   └── style.css          # Main stylesheet
├── js/
│   └── main.js            # JavaScript functionality
├── pages/
│   ├── institutes.html    # All research institutes
│   ├── research.html      # Research portal & projects
│   ├── publications.html  # Publications database
│   ├── news-events.html   # News & upcoming events
│   ├── collaboration.html # Collaboration opportunities
│   ├── about.html         # About the academy
│   ├── contact.html       # Contact form & information
│   ├── membership.html    # Membership application
│   ├── member-portal.html # Member login portal
│   ├── careers.html       # Career opportunities
│   ├── grants.html        # Grant applications
│   ├── education.html     # Educational programs
│   ├── ethics.html        # Ethics guidelines
│   ├── privacy.html       # Privacy policy
│   └── terms.html         # Terms of use
└── images/                # Image assets (placeholder)
```

## 🎨 Features

### Homepage
- Hero section with mission statement and key statistics
- Quick access cards to major sections
- Featured institutes showcase
- Research highlights
- Latest news and events
- Call-to-action sections

### Institute Pages
- Comprehensive directory of all 24 institutes
- Organized by discipline categories:
  - Physical Sciences & Engineering
  - Life Sciences & Medicine
  - Computer Science & Technology
  - Environmental & Earth Sciences
  - Social Sciences & Humanities
- Search and filter functionality
- Member count and publication statistics

### Research Portal
- Current research areas overview
- Featured research projects
- Research data repository
- Impact metrics and statistics
- Project collaboration opportunities

### Publications Database
- Advanced search with multiple filters
- Publication listings with full metadata
- Download and citation options
- Annual reports section
- Publication statistics

### News & Events
- Latest academy news
- Upcoming events calendar
- Event registration functionality
- Filterable by date and category

### Contact Page
- Contact form with validation
- Department-specific contact information
- Interactive campus map
- Office hours and locations

### About Us
- Mission and values
- Leadership team profiles
- Governance structure
- Historical timeline
- Impact statistics

## 🚀 Getting Started

1. **Open the website:**
   - Simply open `index.html` in any modern web browser
   - No server or build process required

2. **Navigate the site:**
   - Use the top navigation menu to access different sections
   - All internal links are functional

3. **Customize content:**
   - Edit HTML files to update text and information
   - Modify `css/style.css` for styling changes
   - Update `js/main.js` for functionality changes

## 🎨 Design Features

- **Modern UI/UX:** Clean, professional design with smooth animations
- **Responsive Design:** Works on desktop, tablet, and mobile devices
- **Color Scheme:** 
  - Primary: #3498db (Blue)
  - Secondary: #2c3e50 (Dark blue-gray)
  - Accent: #e74c3c (Red)
  - Gradient: #667eea to #764ba2 (Purple gradient)

- **Typography:** Segoe UI font family for clarity and readability
- **Interactive Elements:** Hover effects, smooth transitions, animated counters
- **Accessibility:** Semantic HTML, proper heading structure, alt text support

## 📱 Responsive Breakpoints

- Desktop: 1024px and above
- Tablet: 768px - 1023px
- Mobile: Below 768px

## ⚙️ JavaScript Functionality

The site includes several interactive features:

- Smooth scrolling navigation
- Form validation
- Search functionality
- Animation on scroll
- Statistics counter animation
- Filter systems
- Back-to-top button
- Mobile menu toggle

## 🔧 Customization Guide

### Changing Colors

Edit the CSS variables in `css/style.css`:

```css
:root {
    --primary-color: #3498db;
    --secondary-color: #2c3e50;
    --accent-color: #e74c3c;
    /* ... */
}
```

### Adding New Pages

1. Copy any existing page from the `pages/` directory
2. Update the content within the main sections
3. Update navigation links in the header
4. Add footer links if needed

### Updating Institute Information

Edit the institute cards in `pages/institutes.html` and homepage `index.html`:

```html
<div class="institute-card">
    <h3>Institute Name</h3>
    <p>Description...</p>
    <div class="institute-meta">
        <span>👥 XXX Members</span>
        <span>📚 XXX Publications</span>
    </div>
</div>
```

### Modifying Statistics

Update the `data-target` attributes for animated counters:

```html
<div class="stat-number" data-target="5000">5,000</div>
```

## 📧 Contact Forms

The contact forms include basic HTML5 validation. For production use, you'll need to:

1. Add server-side processing (PHP, Node.js, etc.)
2. Implement email sending functionality
3. Add CAPTCHA for spam protection
4. Store form submissions in a database

## 🌐 Browser Compatibility

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Opera (latest)

## 📝 Content Guidelines

When adding content:

1. **Keep it concise:** Use clear, accessible language
2. **Update metadata:** Change page titles and descriptions
3. **Optimize images:** Use appropriate image sizes
4. **Maintain consistency:** Follow existing patterns
5. **Test links:** Ensure all internal links work correctly

## 🔐 Security Notes

For production deployment:

1. Implement HTTPS
2. Add security headers
3. Sanitize all form inputs
4. Implement rate limiting
5. Add authentication for member portals
6. Regular security audits

## 📈 Future Enhancements

Potential additions:

- Backend database integration
- User authentication system
- Content management system (CMS)
- Real-time search
- Advanced filtering
- Data visualization dashboards
- Multi-language support (i18n)
- Blog platform
- Event calendar integration
- Payment processing for memberships

## 📞 Support

For questions or issues with the website:
- Email: contact@nationalacademy.org
- Phone: +1 (555) 123-4567

## 📄 License

Copyright © 2026 National Academy of Sciences. All rights reserved.

---

**Note:** This is a complete front-end website. For full functionality (forms, database, user authentication), you'll need to add back-end services.
